ফুট-ইঞ্চি ক্যালকুলেটর — Android Studio Project

এই ZIP ফাইলে Android অ্যাপের সম্পূর্ণ সোর্স প্রজেক্ট আছে।
এটি এখনো তৈরি করা APK ফাইল নয়।

APK বানানোর নিয়ম:
১. কম্পিউটারে Android Studio ইনস্টল করুন।
২. ZIP ফাইলটি Extract করুন।
৩. Android Studio খুলে Open নির্বাচন করে FootInchCalculator ফোল্ডারটি খুলুন।
৪. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
৫. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
৬. APK তৈরি হলে Android Studio-তে 'locate' চাপলে APK ফাইলটি পাবেন।
৭. APK ফোনে কপি করে খুলুন এবং Android-এর নির্দেশনা অনুসারে ইনস্টল করুন।

অ্যাপটি অফলাইনে চলে; কোনো ইন্টারনেট পারমিশন চায় না।
প্রয়োজন: Android Studio এবং Android SDK Platform 35।


কম্পিউটার ছাড়া GitHub Actions দিয়ে APK বানানোর বিকল্প:
১. GitHub-এ একটি নতুন repository তৈরি করুন।
২. এই ZIP Extract করে ভেতরের সব ফাইল repository-তে upload/commit করুন।
৩. Actions ট্যাবে গিয়ে 'Build Android APK' workflow চালু করুন (অথবা main branch-এ push করুন)।
৪. Workflow সফল হলে Actions > সর্বশেষ run > Artifacts থেকে
   FootInchCalculator-debug-apk ডাউনলোড করুন।
৫. ZIP extract করে app-debug.apk ফোনে ইনস্টল করুন।
